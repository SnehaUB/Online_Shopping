package com.dp.onlineshopping;

public class AbstractFactory {
	
	  
	   public Factory gettype(String type){
	      if(type == null){
	         return null;
	      }		
	      if(type.equalsIgnoreCase("BOOK")){
	         return new Book();
	      } else if(type.equalsIgnoreCase("PENCIL")){
	         return new Pencil();
	      }
	      
	      return null;
	   
   }
	   public void display(){
		   System.out.println("PRODUCTS:\n");
		   System.out.println("BOOK\n");
		   System.out.println("PENCIL\n");
		   
	   }
}
