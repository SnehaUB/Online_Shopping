package com.dp.onlineshopping;

import java.util.ArrayList;

public class Seller {

	
	
	public void process(ArrayList<Buyer> orderList) {
		AbstractFactory af = new AbstractFactory();
		Product addbuyer = new Product();
		
		System.out.println("\t\tPRODUCT \t \t  QUANTITY\n");
        for(int i=0;i<orderList.size();i++){
			
			String s=orderList.get(i).getName();
			Factory fac = af.gettype(s);
			
			int q=fac.getquantity();
		   
			System.out.println("\t\t"+s+"\t\t\t "+ q +"\n");
			
		
			
		}
        System.out.println("------------------------------------------------");
		
		
		System.out.println("\t\tPRODUCT \t \t  QUANTITY\n");
		for(int i=0;i<orderList.size();i++){
			
			String s=orderList.get(i).getName();
			Factory fac = af.gettype(s);
			int quant = orderList.get(i).getQuant();
			
			int q=fac.getquantity();
			
			int k = q - quant;
			
		    fac.setquantity(q-quant);
		    
		    System.out.println("\t\t"+s+"\t\t\t "+fac.getquantity());
		
			
		}
		
		//refill(orderList);
		
		
		
	}
	public void refill(ArrayList<Buyer> orderList){
		AbstractFactory af = new AbstractFactory();
		Product addbuyer = new Product();
	String s=orderList.get(0).getName();
	Factory fac = af.gettype(s);
	fac.setquantity(2000);
	int t = fac.getquantity();
	System.out.println("Quantity set to "+ t); 
    addbuyer.check(orderList.get(0),t);
}
}
