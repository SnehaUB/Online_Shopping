package com.dp.onlineshopping;


import java.util.ArrayList;
import java.util.Scanner;

public class Buyer implements Observer
{   String s ;
	private String name;
	private int quantity;
	Scanner sn = new Scanner(System.in);
	
	
	AbstractFactory ab = new AbstractFactory();
	Product addbuyer = new Product();
	 public String getName(){
		 return name;
		 
	 }
	 public int getQuant(){
		 return quantity;
		 
	 }

	 public Buyer(){
		 
	 }
	 
	public Buyer(String name, int quantity){
		this.name=name;
		this.quantity=quantity;
	       
	}
	public void setOrder(String name, int quantity){
		this.name=name;
		this.quantity=quantity;
		
	}
	

	public void notification(String availability){
		
		System.out.println("THE Product is available");
		
	}
	public void logout(){
		System.out.println("logged out!");
	}

}
