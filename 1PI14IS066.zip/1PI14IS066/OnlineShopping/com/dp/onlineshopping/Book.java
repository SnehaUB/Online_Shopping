package com.dp.onlineshopping;

public class Book implements Factory{
	int quantity=200;
	int i=1;
	 @Override
	   public void setquantity(int qa) {
	   	// TODO Auto-generated method stub
		   if(i==0){
			   quantity=100;
			   i++;
		   }
		   else{
	   	    quantity = qa;
		   }
	   }
	
	public int getquantity() {
		
		
		 
		return quantity;
		
	}

   @Override
	public void name() {
		System.out.println("BOOK");
		
	}
  


}
