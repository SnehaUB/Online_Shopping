package com.dp.onlineshopping;

public class Pencil implements Factory{
	int quantity=50;int i=1;
	public int getquantity() {
		//int quantity = 50;
		return  quantity;
		
	}

   @Override
	public void name() {
		System.out.println("PENCIL");
		
	}

@Override
public void setquantity(int qa) {
	// TODO Auto-generated method stub
	 if(i==0){
		   quantity=50;
		   i++;
	   }else{
	quantity = qa;
}
}



	

}
