package com.dp.onlineshopping;

public interface Observer {
	public void notification(String availability);
}
