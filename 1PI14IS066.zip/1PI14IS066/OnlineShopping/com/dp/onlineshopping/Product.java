package com.dp.onlineshopping;

import java.util.ArrayList;

public class Product implements Subject {
	
	private ArrayList<Observer> observers = new ArrayList<Observer>();
   // private String productName;
   // private String productType;
    String availability;
    AbstractFactory ab = new AbstractFactory();
    int i=0;
	@Override
	public void registerObserver(Observer observer) {
		 observers.add(observer);
		 
	}
	public void check(Buyer b, int t){
		
		//Factory f = ab.gettype(b.getName());
		int f1 = t;
		int f2 = b.getQuant();
		if(f1>f2){
			notifyObservers();
		}
		else{
			System.out.println("Product Not Available\n\n");
		}
	}

	public void removeObserver(Observer observer) {
		 observers.remove(observer);
		
	}
	@Override
	public void notifyObservers() {
		// TODO Auto-generated method stub
		System.out.println("Notifying to all the subscribers when product became available");
		 for (Observer ob : observers) {
            ob.notification(this.availability);
            //System.out.println(this.availability); 
     }
		
		/*for(int i=0;i<observers.size();i++){
			System.out.println(this.availability); 
			observers.get(0).notification(this.availability);
		}*/
		
	}

}
