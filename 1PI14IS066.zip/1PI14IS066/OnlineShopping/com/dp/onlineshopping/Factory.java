package com.dp.onlineshopping;

public interface Factory {
	int  getquantity();
	void name();
	void setquantity(int a);
	//public void notification();

}
