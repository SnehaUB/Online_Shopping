package com.dp.onlineshopping;

import java.util.ArrayList;
import java.util.Scanner;

public class Client {

	
	
	public static void main(String[] args) {
		
		String s;
		ArrayList<Buyer> orderList = new ArrayList<Buyer>();
		Product addbuyer = new Product();
		AbstractFactory ab = new AbstractFactory();
		ab.display();
		
		Buyer b = new Buyer("BOOK",100);
		func(b,orderList);
		Buyer buyer2 = new Buyer("PENCIL",50);
		//buyer2.placeOrder(buyer2);
		func(buyer2,orderList);
		
		Seller se=new Seller();
		se.process(orderList);
	   
		
	}
		
		public static void func(Buyer b,ArrayList<Buyer> orderList){
			AbstractFactory ab = new AbstractFactory();
		Factory fac = ab.gettype(b.getName());
		Product addbuyer = new Product();
		Scanner sn = new Scanner(System.in);
		if(fac.getquantity()<b.getQuant()){
			System.out.println("Cannot place order: Do you want to notify?? Y/N");
			 String s = sn.next();
			
			//if(s=="Y"){
				
				//System.out.println(s);
				addbuyer.registerObserver(b);
			//}
		}
		else{
			orderList.add(b);
			//System.out.println(orderList.size());
		 }
		
		
	
							
	  	}
}


